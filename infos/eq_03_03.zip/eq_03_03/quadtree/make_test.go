package quadtree
import (
	"testing" 
	"reflect"
)

// Realisé par Bernard

func Test1Case3(t *testing.T){
	var res *node
	n :=node{topLeftX:0,topLeftY:0,width:1,height:1,content:0,topLeftNode : nil, topRightNode : nil,bottomLeftNode :nil,bottomRightNode :nil }
	res=&n
	val:=MakeFromArray([][] int {{0}})

	if !reflect.DeepEqual(res,val.root){
		t.Error("la fonction MakeFromArray devrait renvoyer",res,"mais renvoie",val)
		return
	}
}