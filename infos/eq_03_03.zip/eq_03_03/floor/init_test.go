package floor

import "testing"

// Realisé par Bernard

func Test1Case(t *testing.T) {
	res := [][]int{{0}}
	val := readFloorFromFile("../floor-files/test1case")
	if res[0][0] != val[0][0] {
		t.Error("la fonction readfloorfromfile(test1case) devrait renvoyer", res, "mais renvoie", val)
		return
	}
}

func TestCarré(t *testing.T) {
	res := [][]int{
		{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
		{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
		{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
		{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
		{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
		{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
		{2, 1, 2, 1, 2, 3, 4, 3, 4, 3},
		{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
		{2, 1, 2, 1, 2, 3, 4, 3, 4, 3},
		{1, 2, 1, 2, 1, 4, 3, 4, 3, 4}}

	val := readFloorFromFile("../floor-files/testcarré")
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < (len(res[0])); ligne++ {
			if res[col][ligne] != val[col][ligne] {
				t.Error("la fonction readfloorfromfile(testcarré) devrait renvoyer", res, "mais renvoie", val)
				return
			}
		}
	}
}

func TestCarréimpaire(t *testing.T) {
	res := [][]int{
		{1, 1, 1, 1, 1, 4, 2, 4, 2},
		{1, 1, 1, 1, 1, 2, 4, 2, 4},
		{1, 1, 1, 1, 1, 4, 2, 4, 2},
		{1, 1, 1, 1, 1, 2, 4, 2, 4},
		{1, 1, 1, 1, 1, 4, 2, 4, 2},
		{2, 2, 2, 2, 2, 3, 1, 4, 2},
		{2, 2, 2, 2, 2, 3, 2, 4, 1},
		{3, 3, 3, 3, 3, 4, 1, 2, 3},
		{3, 3, 3, 3, 3, 1, 2, 4, 3}}

	val := readFloorFromFile("../floor-files/testcarréimpair")
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < len(res[0]); ligne++ {
			if res[col][ligne] != val[col][ligne] {
				t.Error("la fonction readfloorfromfile(testcarréimpair) devrait renvoyer", res, "mais renvoie", val)
				return
			}
		}
	}
}

func TestCarrépuissance2(t *testing.T) {
	res := [][]int{
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 2, 1, 2, 4, 4, 3, 3},
		{2, 1, 2, 1, 4, 4, 3, 3},
		{1, 2, 1, 2, 3, 3, 4, 4},
		{2, 1, 2, 1, 3, 3, 4, 4}}

	val := readFloorFromFile("../floor-files/testcarrépuissance2")
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < len(res[0]); ligne++ {
			if res[col][ligne] != val[col][ligne] {
				t.Error("la fonction readfloorfromfile(testcarrépuissance2) devrait renvoyer", res, "mais renvoie", val)
				return
			}
		}
	}
}

func TestRectangleLongueur(t *testing.T) {
	res := [][]int{
		{1, 1, 4, 1, 2, 2, 2, 4, 4, 4, 4, 4, 3, 1, 2, 2, 1, 1, 4, 1, 2, 2, 2, 4, 4, 4, 4, 4, 3, 1, 2, 2},
		{1, 4, 3, 3, 1, 4, 4, 2, 3, 2, 2, 1, 1, 4, 4, 3, 1, 4, 3, 3, 1, 4, 4, 2, 3, 2, 2, 1, 1, 4, 4, 3},
		{1, 4, 4, 3, 3, 4, 4, 2, 2, 3, 3, 1, 1, 4, 3, 4, 1, 4, 4, 3, 3, 4, 4, 2, 2, 3, 3, 1, 1, 4, 3, 4},
		{2, 3, 4, 4, 1, 4, 4, 1, 1, 2, 2, 3, 3, 2, 2, 4, 2, 3, 4, 4, 1, 4, 4, 1, 1, 2, 2, 3, 3, 2, 2, 4},
		{3, 3, 4, 4, 4, 4, 4, 4, 1, 1, 2, 2, 1, 4, 4, 4, 3, 3, 4, 4, 4, 4, 4, 4, 1, 1, 2, 2, 1, 4, 4, 4}}

	val := readFloorFromFile("../floor-files/testrectanglelongueur")
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < len(res[0]); ligne++ {
			if res[col][ligne] != val[col][ligne] {
				t.Error("la fonction readfloorfromfile(testrectanglelongueur) devrait renvoyer", res, "mais renvoie", val)
				return
			}
		}
	}
}

func testrectanglelargeur(t *testing.T) {
	res := [][]int{
		{1, 1, 4, 2, 4, 2, 3, 1},
		{1, 1, 4, 2, 3, 2, 3, 3},
		{1, 2, 4, 3, 2, 1, 4, 2},
		{1, 1, 4, 2, 3, 2, 1, 4},
		{1, 4, 4, 4, 1, 3, 2, 2},
		{1, 1, 4, 3, 6, 2, 2, 2},
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 1, 1, 1, 2, 3, 2, 4},
		{1, 1, 1, 1, 4, 2, 3, 1},
		{1, 1, 1, 1, 2, 3, 1, 4},
		{1, 1, 1, 1, 2, 2, 3, 3}}

	val := readFloorFromFile("../floor-files/testrectanglelargeur")
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < len(res[0]); ligne++ {
			if res[col][ligne] != val[col][ligne] {
				t.Error("la fonction readfloorfromfile(testrectanglelargeur) devrait renvoyer", res, "mais renvoie", val)
				return
			}
		}
	}
}
