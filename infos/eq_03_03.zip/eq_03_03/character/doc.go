/*
character est le paquet qui permet de définir
la manière dont le personnage se comporte.
Pour le moment ceci prend en compte :
  - l'affichage
  - les contrôles
  - l'animation
*/
package character
