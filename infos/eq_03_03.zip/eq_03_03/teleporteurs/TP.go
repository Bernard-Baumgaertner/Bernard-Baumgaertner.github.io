package teleporteurs

// Portail est la structure de donées pour la téléportations
// Les vhamps non exportés sont :
//    - existe : Permet de savoir si le portail est sur le terrain
// Les champs exportés sont :
//    - X, Y : Les coordonnées du portail
//    - Destination : un pointeur vers un autre portail où l'on doit se téléporter.

type Portail struct {
	X           int
	Y           int
	existe      bool
	Destination *Portail
}
