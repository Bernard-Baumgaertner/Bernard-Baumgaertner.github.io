package teleporteurs

import (
	"image"

	"gitlab.univ-nantes.fr/jezequel-l/quadtree/assets"
	"gitlab.univ-nantes.fr/jezequel-l/quadtree/configuration"

	"github.com/hajimehoshi/ebiten/v2"
)

func Draw(screen *ebiten.Image, Xp, Yp, Cx, Cy int, a, b Portail) {
	topLeftX := Cx - configuration.Global.ScreenCenterTileX
	topLeftY := Cy - configuration.Global.ScreenCenterTileY
	if a.existe {
		opA := &ebiten.DrawImageOptions{}
		opA.GeoM.Translate((float64(a.X-topLeftX) * 16), (float64(a.Y-topLeftY) * 16))
		screen.DrawImage(assets.TeleportImage.SubImage(
			image.Rect(0*16, 0, 1*16, 16),
		).(*ebiten.Image), opA)
	}
	if b.existe {
		opB := &ebiten.DrawImageOptions{}
		opB.GeoM.Translate((float64(b.X-topLeftX) * 16), (float64(b.Y-topLeftY) * 16))
		screen.DrawImage(assets.TeleportImage.SubImage(
			image.Rect(1*16, 0, 2*16, 16),
		).(*ebiten.Image), opB)
	}

}
