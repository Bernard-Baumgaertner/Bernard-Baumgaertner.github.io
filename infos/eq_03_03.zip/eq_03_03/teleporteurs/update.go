package teleporteurs

import (
	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/inpututil"
	"gitlab.univ-nantes.fr/jezequel-l/quadtree/camera"
	"gitlab.univ-nantes.fr/jezequel-l/quadtree/character"
	"gitlab.univ-nantes.fr/jezequel-l/quadtree/configuration"
)

// compteur
var count int

// cette fonction permet de placer les 2 portails pour la téléportation avec la touche P
func PlacePortails(Chx, Chy int, a, b *Portail) {
	var Pcount *int = &count
	if inpututil.IsKeyJustPressed(ebiten.KeyP) && configuration.Global.Teleport {
		*Pcount = *Pcount + 1
		if !a.existe || *Pcount%2 != 0 {
			a.X = Chx
			a.Y = Chy
			a.existe = true
		} else {
			b.X = Chx
			b.Y = Chy
			b.existe = true
		}
	}
}

// cette fonction permet de téléporter le joueur aux différents portails avec la touche T
func Teleport(c *camera.Camera, ch *character.Character, a, b *Portail, contentWidth, contentHeight int) {
	if inpututil.IsKeyJustPressed(ebiten.KeyT) && a.existe && b.existe && configuration.Global.Teleport {
		if ch.X == a.X && ch.Y == a.Y {
			ch.Y = a.Destination.Y
			ch.X = a.Destination.X
			if configuration.Global.CameraMode == 2 && ch.X >= contentWidth-1-configuration.Global.NumTileX/2 {
				c.X = contentWidth - 1 - (configuration.Global.NumTileX-1)/2
			} else if configuration.Global.CameraMode == 2 && ch.X < configuration.Global.NumTileX/2 {
				c.X = 0 + configuration.Global.NumTileX/2
			} else {
				c.X = a.Destination.X
			}
			if configuration.Global.CameraMode == 2 && ch.Y >= contentHeight-1-configuration.Global.NumTileY/2 {
				c.Y = contentHeight - 1 - (configuration.Global.NumTileY-1)/2
			} else if configuration.Global.CameraMode == 2 && ch.Y < configuration.Global.NumTileY/2 {
				c.Y = 0 + configuration.Global.NumTileY/2
			} else {
				c.Y = a.Destination.Y
			}
		} else if ch.X == b.X && ch.Y == b.Y {
			ch.X = b.Destination.X
			ch.Y = b.Destination.Y
			if configuration.Global.CameraMode == 2 && ch.X >= contentWidth-1-configuration.Global.NumTileX/2 {
				c.X = contentWidth - 1 - (configuration.Global.NumTileX-1)/2
			} else if configuration.Global.CameraMode == 2 && ch.X < configuration.Global.NumTileX/2 {
				c.X = 0 + configuration.Global.NumTileX/2
			} else {
				c.X = b.Destination.X
			}
			if configuration.Global.CameraMode == 2 && ch.Y >= contentHeight-1-configuration.Global.NumTileY/2 {
				c.Y = contentHeight - 1 - (configuration.Global.NumTileY-1)/2
			} else if configuration.Global.CameraMode == 2 && ch.Y < configuration.Global.NumTileY/2 {
				c.Y = 0 + configuration.Global.NumTileY/2
			} else {
				c.Y = b.Destination.Y
			}
		}
	}
}

// Cette fonction permet de supprimer le portail sur lequel est placé le joueur
func SuppPortail(ch *character.Character, a, b *Portail) {
	var P2count *int = &count
	if inpututil.IsKeyJustPressed(ebiten.KeyS) && ch.X == a.X && ch.Y == a.Y && configuration.Global.Teleport {
		a.existe = false
		if *P2count%2 != 0 {
			*P2count = *P2count + 1
		}
	} else if inpututil.IsKeyJustPressed(ebiten.KeyS) && ch.X == b.X && ch.Y == b.Y && configuration.Global.Teleport {
		b.existe = false
		if *P2count%2 == 0 {
			*P2count = *P2count + 1
		}
	}
}
