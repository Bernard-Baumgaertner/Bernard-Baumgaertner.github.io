package quadtree

// Realisé par Jules

// Construit un quadtree à partir d'un tableau
func MakeFromArray(floorContent [][]int) (q Quadtree) {
	// TODO
	q.Width = len(floorContent[0])
	q.Height = len(floorContent)
	racine := &node{
		topLeftX: 0,
		topLeftY: 0,
		width:    q.Width,
		height:   q.Height,
		content:  -1,
	}
	q.root = rec(*racine, floorContent)
	return q
}

// Vérifie si toutes les valeurs sont les mêmes pour une node
func verif(n node, floorContent [][]int) (test bool) {
	val := floorContent[n.topLeftY][n.topLeftX]
	for y := n.topLeftY; y < n.topLeftY+n.height; y++ {
		for x := n.topLeftX; x < n.topLeftX+n.width; x++ {
			if floorContent[y][x] != val {
				return false
			}
		}
	}
	return true
}

// Crée récursivement toutes les nodes du quadtree
func rec(n node, floorContent [][]int) (m *node) {
	if verif(n, floorContent) {
		return &node{
			topLeftX: n.topLeftX,
			topLeftY: n.topLeftY,
			width:    n.width,
			height:   n.height,
			content:  floorContent[n.topLeftY][n.topLeftX],
		}
	} else if n.height == 1 {
		topLeft := &node{
			topLeftX: n.topLeftX,
			topLeftY: n.topLeftY,
			width:    (n.width + 1) / 2,
			height:   1,
			content:  -1,
		}

		topRight := &node{
			topLeftX: n.topLeftX + (n.width+1)/2,
			topLeftY: n.topLeftY,
			width:    (n.width+1)/2 - n.width%2,
			height:   1,
			content:  -1,
		}

		return &node{
			topLeftX:     n.topLeftX,
			topLeftY:     n.topLeftY,
			width:        n.width,
			height:       n.height,
			content:      n.content,
			topLeftNode:  rec(*topLeft, floorContent),
			topRightNode: rec(*topRight, floorContent),
		}

	} else if n.width == 1 {
		topLeft := &node{
			topLeftX: n.topLeftX,
			topLeftY: n.topLeftY,
			width:    1,
			height:   (n.height + 1) / 2,
			content:  -1,
		}

		bottomLeft := &node{
			topLeftX: n.topLeftX,
			topLeftY: n.topLeftY + (n.height+1)/2,
			width:    1,
			height:   (n.height+1)/2 - n.height%2,
			content:  -1,
		}

		return &node{
			topLeftX:       n.topLeftX,
			topLeftY:       n.topLeftY,
			width:          n.width,
			height:         n.height,
			content:        n.content,
			topLeftNode:    rec(*topLeft, floorContent),
			bottomLeftNode: rec(*bottomLeft, floorContent),
		}

	} else {
		topLeft := &node{
			topLeftX: n.topLeftX,
			topLeftY: n.topLeftY,
			width:    (n.width + 1) / 2,
			height:   (n.height + 1) / 2,
			content:  -1,
		}

		topRight := &node{
			topLeftX: n.topLeftX + (n.width+1)/2,
			topLeftY: n.topLeftY,
			width:    (n.width+1)/2 - n.width%2,
			height:   (n.height + 1) / 2,
			content:  -1,
		}

		bottomLeft := &node{
			topLeftX: n.topLeftX,
			topLeftY: n.topLeftY + (n.height+1)/2,
			width:    (n.width + 1) / 2,
			height:   (n.height+1)/2 - n.height%2,
			content:  -1,
		}

		bottomRight := &node{
			topLeftX: n.topLeftX + (n.width+1)/2,
			topLeftY: n.topLeftY + (n.height+1)/2,
			width:    (n.width+1)/2 - n.width%2,
			height:   (n.height+1)/2 - n.height%2,
			content:  -1,
		}

		return &node{
			topLeftX:        n.topLeftX,
			topLeftY:        n.topLeftY,
			width:           n.width,
			height:          n.height,
			content:         n.content,
			topLeftNode:     rec(*topLeft, floorContent),
			topRightNode:    rec(*topRight, floorContent),
			bottomLeftNode:  rec(*bottomLeft, floorContent),
			bottomRightNode: rec(*bottomRight, floorContent),
		}
	}
}
