package game

import (
	"fmt"
	"log"
	"os"
	"strconv"
)

// écriture d'un terrain dans un fichier à partir d'un tableau
func Save(tab [][]int) {
	var myFile *os.File
	var err error
	var ligne string
	myFile, err = os.Create("../floor-files/newSave")
	if err != nil {
		log.Fatal(err)
	}

	for y:=0;y<len(tab);y++ {
		for i:=0;i<len(tab[0]);i++ {
			ligne = ligne + strconv.Itoa(tab[y][i])
		}
		_,err = fmt.Fprintln(myFile, ligne)
		if err != nil {
			log.Fatal(err)
	}
		ligne = ""
	}

	err = myFile.Close()
	if err != nil {
		log.Fatal(err)
	}
}


