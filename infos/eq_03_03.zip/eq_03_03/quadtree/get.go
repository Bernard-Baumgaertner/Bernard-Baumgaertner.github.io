package quadtree

import "gitlab.univ-nantes.fr/jezequel-l/quadtree/configuration"

// Realisé par Jules

// GetContent remplit le tableau contentHolder (qui représente
// un terrain dont la case le plus en haut à gauche a pour coordonnées
// (topLeftX, topLeftY)) à partir du qadtree q.
func (q Quadtree) GetContent(topLeftX, topLeftY int, contentHolder [][]int) {
	// TODO
	if configuration.Global.CameraMode == 0 {
		for y := 0; y < len(contentHolder); y++ {
			for x := 0; x < len(contentHolder[0]); x++ {
				contentHolder[y][x] = -1
			}
		}
	}
	getContentRecursive(*q.root, topLeftX, topLeftY, contentHolder)
}

// Fonction qui affecte une valeur à chaque case de contentHolder
func getContentRecursive(n node, topLeftX, topLeftY int, contentHolder [][]int) {
	if configuration.Global.CameraMode == 0 {
		for y := 0; y < len(contentHolder)/2+len(contentHolder)%2; y++ {
			for x := 0; x < len(contentHolder[y])/2+len(contentHolder[y])%2; x++ {
				contentHolder[y+(len(contentHolder)/2)][x+(len(contentHolder[y])/2)] = get_value(&n, x, y)
			}
		}
	} else if configuration.Global.CameraMode == 1 {
		for y := 0; y < len(contentHolder); y++ {
			for x := 0; x < len(contentHolder[y]); x++ {
				contentHolder[y][x] = get_value(&n, x+topLeftX, y+topLeftY)
			}
		}
	} else if configuration.Global.CameraMode == 2 {
		for y := 0; y < len(contentHolder); y++ {
			for x := 0; x < len(contentHolder[y]); x++ {
				contentHolder[y][x] = get_value(&n, x+topLeftX, y+topLeftY)
			}
		}
	}
}

// Fonction récursive pour obtenir le contenu du quadtree case par case à partir des coordonnées
func get_value(n *node, x, y int) (v int) {
	if n == nil {
		return -1
	}
	if x >= n.topLeftX && x < n.topLeftX+n.width && y >= n.topLeftY && y < n.topLeftY+n.height {
		if n.content != -1 {
			return n.content
		} else {
			valtopLef := get_value(n.topLeftNode, x, y)
			valtopRight := get_value(n.topRightNode, x, y)
			valbottomLeft := get_value(n.bottomLeftNode, x, y)
			valbottomRight := get_value(n.bottomRightNode, x, y)
			if valtopLef != -1 {
				return valtopLef
			} else if valtopRight != -1 {
				return valtopRight
			} else if valbottomLeft != -1 {
				return valbottomLeft
			} else if valbottomRight != -1 {
				return valbottomRight
			}
			return -1
		}
	} else {
		return -1
	}
}
