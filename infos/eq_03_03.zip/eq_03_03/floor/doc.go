/*
floor est le paquet qui gère la configuration du sol sur lequel le
personnage se déplace. Sa principale fonction est de fournir, chaque
1/60 de seconde et en fonction de la position absolue de la caméra,
une structure de données représentant les cases de terrain visibles
à l'écran.
*/
package floor
