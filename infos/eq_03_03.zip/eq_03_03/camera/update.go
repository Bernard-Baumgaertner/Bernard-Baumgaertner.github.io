package camera

import (
	"gitlab.univ-nantes.fr/jezequel-l/quadtree/configuration"
)

// Update met à jour la position de la caméra à chaque pas
// de temps, c'est-à-dire tous les 1/60 secondes.
func (c *Camera) Update(characterPosX, characterPosY, contentHeight, contentWidth int) {

	switch configuration.Global.CameraMode {
	case Static:
		c.updateStatic()
	case FollowCharacter:
		c.updateFollowCharacter(characterPosX, characterPosY)
	case Bloquee:
		c.updateBloquee(characterPosX, characterPosY, contentHeight, contentWidth)
	}
}

// updateStatic est la mise-à-jour d'une caméra qui reste
// toujours à la position (0,0). Cette fonction ne fait donc
// rien.
func (c *Camera) updateStatic() {}

// updateFollowCharacter est la mise-à-jour d'une caméra qui
// suit toujours le personnage. Elle prend en paramètres deux
// entiers qui indiquent les coordonnées du personnage et place
// la caméra au même endroit.
func (c *Camera) updateFollowCharacter(characterPosX, characterPosY int) {
	c.X = characterPosX
	c.Y = characterPosY
}

// updateBloquee est la mise-à-jour d'une caméra qui
// suit toujours le personnage sans afficher les bordures noires du terrain. Elle prend en paramètres quatre
// entiers qui indiquent les coordonnées du personnage, la taille du terrain et place
// la caméra en fonction de la position du personnage par rapport au bord.
func (c *Camera) updateBloquee(characterPosX, characterPosY, contentHeight, contentWidth int) {
	if characterPosX-(configuration.Global.NumTileX/2) > -1 && characterPosX-(configuration.Global.NumTileX/2) < contentWidth-configuration.Global.NumTileX+1 {
		c.X = characterPosX
	}
	if characterPosY-(configuration.Global.NumTileY/2) > -1 && characterPosY-(configuration.Global.NumTileY/2) < contentHeight-configuration.Global.NumTileY+1 {
		c.Y = characterPosY
	}
}
