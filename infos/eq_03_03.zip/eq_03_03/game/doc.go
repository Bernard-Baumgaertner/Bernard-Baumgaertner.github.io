/*
game est le paquet qui se charge de définir un type pour représenter
les données du jeu. Il est aussi responsable de faire en sorte que ce
type dispose de toutes les méthodes nécessaires pour mettre en œuvre
le type Game de Ebitengine (nécessaire à l'exécution du jeu).
*/
package game
