package teleporteurs

// initialise le champ "existe" d'un portail à false
func Init() Portail {
	return Portail{existe: false}
}
