/*
quadtree est le paquet qui fournit la structure de données
pour les arbres quaternaires ainsi que les fonctions et
méthodes pour manipuler ces arbres.
*/
package quadtree
