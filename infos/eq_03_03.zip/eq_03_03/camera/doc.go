/*
camera est le paquet qui prend en charge la gestion d'une
caméra abtraite. L'idée est que la position de la caméra
représente toujours le centre de l'affichage à l'écran.

Pour le moment, la caméra peut soit suivre le personnage soit
rester immobile. On peut choisir entre ces deux modes à l'aide
du fichier de configuration du jeu (fourni avec la paquet
quadtree/cmd).
*/
package camera
