package quadtree

import "testing"

// Realisé par Jules

/*
	{
	    "DebugMode": false,
	    "NumTileX": 5,
	    "NumTileY": 5,
	    "TileSize": 16,
	    "CameraMode": 1,
	    "FloorKind": 2,
	}

Voici la configuration utilisée pour les prochains tests
*/
func Test1Case(t *testing.T) {
	contentHolder := [][]int{
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0}}
	tableau := [][]int{{0}}
	res := [][]int{
		{-1, -1, -1, -1, -1},
		{-1, -1, -1, -1, -1},
		{-1, -1, 0, -1, -1},
		{-1, -1, -1, -1, -1},
		{-1, -1, -1, -1, -1},
	}
	MakeFromArray(tableau).GetContent(0, 0, contentHolder)
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < (len(res[0])); ligne++ {
			if res[col][ligne] != contentHolder[col][ligne] {
				t.Error("la fonction devrait renvoyer", res, " mais renvoie", contentHolder)
				return
			}
		}
	}
}

func TestCarré(t *testing.T) {
	contentHolder := [][]int{
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0}}

	tableau := [][]int{
		{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
		{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
		{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
		{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
		{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
		{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
		{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
		{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
		{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
		{1, 2, 1, 2, 1, 4, 3, 4, 3, 4}}

	res := [][]int{
		{-1, -1, -1, -1, -1},
		{-1, -1, -1, -1, -1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
	}
	MakeFromArray(tableau).GetContent(0, 0, contentHolder)
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < (len(res[0])); ligne++ {
			if res[col][ligne] != contentHolder[col][ligne] {
				t.Error("la fonction devrait renvoyer", res, " mais renvoie", contentHolder)
				return
			}
		}
	}
}

func TestCarréimpair(t *testing.T) {
	contentHolder := [][]int{
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0}}
	tableau := [][]int{
		{1, 1, 1, 1, 1, 4, 2, 4, 2},
		{1, 1, 1, 1, 1, 4, 2, 4, 2},
		{1, 1, 1, 1, 1, 4, 2, 4, 2},
		{1, 1, 1, 1, 1, 4, 2, 4, 2},
		{1, 1, 1, 1, 1, 4, 2, 4, 2},
		{2, 2, 2, 2, 2, 3, 1, 4, 2},
		{2, 2, 2, 2, 2, 3, 1, 4, 2},
		{2, 2, 2, 2, 2, 3, 1, 4, 2},
		{2, 2, 2, 2, 2, 3, 1, 4, 2}}
	res := [][]int{
		{-1, -1, -1, -1, -1},
		{-1, -1, -1, -1, -1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
	}
	MakeFromArray(tableau).GetContent(0, 0, contentHolder)
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < (len(res[0])); ligne++ {
			if res[col][ligne] != contentHolder[col][ligne] {
				t.Error("la fonction devrait renvoyer", res, " mais renvoie", contentHolder)
				return
			}
		}
	}
}

func TestCarrépuissance2(t *testing.T) {

	contentHolder := [][]int{
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0},
		{0, 0, 0, 0, 0}}
	tableau := [][]int{
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 1, 1, 1, 2, 2, 2, 2},
		{1, 2, 1, 2, 4, 4, 3, 3},
		{1, 2, 1, 2, 4, 4, 3, 3},
		{1, 2, 1, 2, 4, 4, 3, 3},
		{1, 2, 1, 2, 4, 4, 3, 3}}
	res := [][]int{
		{-1, -1, -1, -1, -1},
		{-1, -1, -1, -1, -1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
	}
	MakeFromArray(tableau).GetContent(0, 0, contentHolder)
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < (len(res[0])); ligne++ {
			if res[col][ligne] != contentHolder[col][ligne] {
				t.Error("la fonction devrait renvoyer", res, " mais renvoie", contentHolder)
				return
			}
		}
	}
}
