package floor

import (
	"bufio"
	"log"
	"math/rand"
	"os"
	"strconv"

	"gitlab.univ-nantes.fr/jezequel-l/quadtree/configuration"
	"gitlab.univ-nantes.fr/jezequel-l/quadtree/quadtree"
)

// Init initialise les structures de données internes de f.
func (f *Floor) Init() {
	f.content = make([][]int, configuration.Global.NumTileY)
	for y := 0; y < len(f.content); y++ {
		f.content[y] = make([]int, configuration.Global.NumTileX)
	}

	switch configuration.Global.FloorKind {
	case fromFileFloor:
		f.FullContent = readFloorFromFile(configuration.Global.FloorFile)
	case quadTreeFloor:
		f.QuadtreeContent = quadtree.MakeFromArray(readFloorFromFile(configuration.Global.FloorFile))
	case random:
		f.QuadtreeContent = quadtree.MakeFromArray(makeRandomFloor())
	}
}

// Realisé par Bernard

// lecture du contenu d'un fichier représentant un terrain
// pour le stocker dans un tableau
func readFloorFromFile(fileName string) (floorContent [][]int) {
	// TODO
	var lu string
	var myFile *os.File
	var err error
	var car int
	myFile, err = os.Open(fileName)
	if err != nil {
		log.Fatal(err)
	}
	var scanner *bufio.Scanner
	scanner = bufio.NewScanner(myFile)
	i := 0
	for scanner.Scan() {
		lu = scanner.Text()
		floorContent = append(floorContent, make([]int, len(lu)))
		for j := 0; j < len(lu); j++ {
			car, err = strconv.Atoi(string(lu[j]))
			if err != nil {
				log.Fatal(err)
			}
			floorContent[i][j] = car
		}
		i++
	}
	if scanner.Err() != nil {
		log.Fatal(scanner.Err())
	}
	err = myFile.Close()
	if err != nil {
		log.Fatal(err)
	}
	return floorContent
}

func makeRandomFloor() (randomFloorContent [][]int) {
	var tab [][]int
	var temp []int
	for y := 0; y < configuration.Global.Height; y++ {
		for i := 0; i < configuration.Global.Width; i++ {
			temp = append(temp, rand.Intn(6))
		}
		tab = append(tab, temp)
		temp = []int{}
	}
	if tab[0][0] == 5 {
		tab[0][0] = 3
	}
	return tab
}
