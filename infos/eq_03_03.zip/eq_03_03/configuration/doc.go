/*
configuration est le paquet qui gère la lecture des
fichiers de configuration et leur enregistrement
dans une structure de données adaptée.

Certains élèments de la configuration sont directement
lus du fichier de configuration et d'autres sont calculés
à partir de ce qui a été lu.
*/
package configuration
