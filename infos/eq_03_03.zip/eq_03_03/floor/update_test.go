package floor

import "testing"

// Realisé par Jules

/*
{
    "DebugMode": false,
    "NumTileX": 5,
    "NumTileY": 5,
    "TileSize": 16,
    "CameraMode": 1,
    "FloorKind": 1,
}
Voici la configuration utilisée pour les prochains tests
*/

func Test1Case2(t *testing.T) {
	f := Floor{
		content: [][]int{
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
		},
		FullContent: [][]int{{0}},
	}
	res := [][]int{
		{-1, -1, -1, -1, -1},
		{-1, -1, -1, -1, -1},
		{-1, -1, 0, -1, -1},
		{-1, -1, -1, -1, -1},
		{-1, -1, -1, -1, -1},
	}
	f.updateFromFileFloor(0, 0)
	val := f.content
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < (len(res[0])); ligne++ {
			if res[col][ligne] != val[col][ligne] {
				t.Error("la fonction devrait renvoyer", res, " mais renvoie", val)
				return
			}
		}
	}
}

func TestCarré2(t *testing.T) {
	f := Floor{
		content: [][]int{
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
		},
		FullContent: [][]int{
			{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
			{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
			{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
			{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
			{1, 1, 1, 1, 1, 3, 3, 3, 3, 3},
			{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
			{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
			{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
			{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
			{1, 2, 1, 2, 1, 4, 3, 4, 3, 4},
		},
	}
	res := [][]int{
		{-1, -1, -1, -1, -1},
		{-1, -1, -1, -1, -1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
	}
	f.updateFromFileFloor(0, 0)
	val := f.content
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < (len(res[0])); ligne++ {
			if res[col][ligne] != val[col][ligne] {
				t.Error("la fonction devrait renvoyer", res, " mais renvoie", val)
				return
			}
		}
	}
}

func TestCarréimpair2(t *testing.T) {
	f := Floor{
		content: [][]int{
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
		},
		FullContent: [][]int{
			{1, 1, 1, 1, 1, 4, 2, 4, 2},
			{1, 1, 1, 1, 1, 4, 2, 4, 2},
			{1, 1, 1, 1, 1, 4, 2, 4, 2},
			{1, 1, 1, 1, 1, 4, 2, 4, 2},
			{1, 1, 1, 1, 1, 4, 2, 4, 2},
			{2, 2, 2, 2, 2, 3, 1, 4, 2},
			{2, 2, 2, 2, 2, 3, 1, 4, 2},
			{2, 2, 2, 2, 2, 3, 1, 4, 2},
			{2, 2, 2, 2, 2, 3, 1, 4, 2},
		},
	}
	res := [][]int{
		{-1, -1, -1, -1, -1},
		{-1, -1, -1, -1, -1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
	}
	f.updateFromFileFloor(0, 0)
	val := f.content
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < (len(res[0])); ligne++ {
			if res[col][ligne] != val[col][ligne] {
				t.Error("la fonction devrait renvoyer", res, " mais renvoie", val)
				return
			}
		}
	}
}

func TestCarrépuissance22(t *testing.T) {
	f := Floor{
		content: [][]int{
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0},
		},
		FullContent: [][]int{
			{1, 1, 1, 1, 2, 2, 2, 2},
			{1, 1, 1, 1, 2, 2, 2, 2},
			{1, 1, 1, 1, 2, 2, 2, 2},
			{1, 1, 1, 1, 2, 2, 2, 2},
			{1, 2, 1, 2, 4, 4, 3, 3},
			{1, 2, 1, 2, 4, 4, 3, 3},
			{1, 2, 1, 2, 4, 4, 3, 3},
			{1, 2, 1, 2, 4, 4, 3, 3},
		},
	}
	res := [][]int{
		{-1, -1, -1, -1, -1},
		{-1, -1, -1, -1, -1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
		{-1, -1, 1, 1, 1},
	}
	f.updateFromFileFloor(0, 0)
	val := f.content
	for col := 0; col < len(res); col++ {
		for ligne := 0; ligne < (len(res[0])); ligne++ {
			if res[col][ligne] != val[col][ligne] {
				t.Error("la fonction devrait renvoyer", res, " mais renvoie", val)
				return
			}
		}
	}
}
